Minecraft 26.x builds (experimental)
------------------------------------
The GitHub workflow (.github/workflows/build.yml) first converts the 1.21.11 sources to Mojang names with
"gradle migrateMappings", then runs port26.py for every Minecraft 26.x version in the matrix. The 26.x jobs are
allowed to fail without affecting the normal 1.21.11 jar. If one fails, the build log shows the compile errors.
