#!/usr/bin/env python3
"""
Builds a Minecraft 26.x jar of PvPCalc.

Minecraft 26.x is unobfuscated (Mojang names) and needs Java 25, so the normal 1.21.11 (Yarn) sources cannot be
used as they are. This script takes the sources that `gradle migrateMappings` already converted to Mojang names
(remappedSrc/), applies the Fabric API renames of 26.1, writes a fresh Gradle project and builds it.

Usage (run from the folder that contains _src/PvPCalc):
    python3 _src/PvPCalc/tools/ci/port26.py --mc 26.2
Options for testing without network:  --api X --loader Y --loom Z --gradle PATH --dry-run
"""
import argparse, json, os, re, shutil, subprocess, sys, urllib.parse, urllib.request, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))          # the PvPCalc project (Yarn, 1.21.11)
UA = {"User-Agent": "PvPCalc-ci/1.0 (GitHub Actions build)"}


def die(msg, code=2):
    print("\n=== PORT26 ERROR: " + msg + " ===", flush=True)
    sys.exit(code)


def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=90) as r:
        return r.read()


def resolve_fabric_api(mc):
    q = urllib.parse.quote('["%s"]' % mc)
    url = "https://api.modrinth.com/v2/project/fabric-api/version?loaders=%5B%22fabric%22%5D&game_versions=" + q
    data = json.loads(get(url).decode())
    if not data:
        die("No Fabric API release found for Minecraft %s (is that version out yet?)" % mc, 3)
    return data[0]["version_number"]


def resolve_loader():
    data = json.loads(get("https://meta.fabricmc.net/v2/versions/loader").decode())
    for e in data:
        if e.get("stable"):
            return e["version"]
    return data[0]["version"]


def resolve_loom():
    try:
        xml = get("https://maven.fabricmc.net/net/fabricmc/fabric-loom/maven-metadata.xml").decode()
        vs = [(int(a), int(b)) for a, b in re.findall(r"<version>(\d+)\.(\d+)-SNAPSHOT</version>", xml)]
        if vs:
            a, b = max(vs)
            return "%d.%d-SNAPSHOT" % (a, b)
    except Exception as e:  # noqa
        print("loom lookup failed:", e)
    return "1.15-SNAPSHOT"


def install_gradle(dest):
    info = json.loads(get("https://services.gradle.org/versions/current").decode())
    url, ver = info["downloadUrl"], info["version"]
    print("Installing Gradle", ver, flush=True)
    os.makedirs(dest, exist_ok=True)
    z = os.path.join(dest, "gradle.zip")
    with open(z, "wb") as f:
        f.write(get(url))
    with zipfile.ZipFile(z) as zf:
        zf.extractall(dest)
    for n in os.listdir(dest):
        b = os.path.join(dest, n, "bin", "gradle")
        if os.path.exists(b):
            os.chmod(b, 0o755)
            return b
    die("Could not install Gradle")


# ---------------- source patches (Fabric API 26.1 renames + mixin targets) ----------------
# (old, new) plain-text replacements applied to every migrated .java file.
REPLACEMENTS = [
    # Fabric API client command API
    ("net.fabricmc.fabric.api.client.command.v2.ClientCommandManager", "net.fabricmc.fabric.api.client.command.v2.ClientCommands"),
    ("ClientCommandManager.", "ClientCommands."),
    # key bindings
    ("net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper", "net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper"),
    ("KeyBindingHelper.registerKeyBinding(", "KeyMappingHelper.registerKeyMapping("),
    # world -> level events
    ("ClientWorldEvents", "ClientLevelEvents"),
    ("AFTER_CLIENT_WORLD_CHANGE", "AFTER_CLIENT_LEVEL_CHANGE"),
    # mixin targets (strings are not touched by the mapping migration)
    ('"onEntityStatus"', '"handleEntityEvent"'),
    ('"onExplosion"', '"handleExplosion"'),
    ('"onWorldTimeUpdate"', '"handleSetTime"'),
    ("attack(Lnet/minecraft/entity/Entity;)V", "attack(Lnet/minecraft/world/entity/Entity;)V"),
    # GUI drawing context was split into an "extractor" in 26.1 (guess - the build log will tell)
    ("net.minecraft.client.gui.GuiGraphics;", "net.minecraft.client.gui.GuiGraphicsExtractor;"),
]
REGEX_REPLACEMENTS = [
    (re.compile(r"\bGuiGraphics\b(?!Extractor)"), "GuiGraphicsExtractor"),
]


def patch_sources(src_dir):
    changed = {}
    for dp, _, files in os.walk(src_dir):
        for f in files:
            if not f.endswith(".java"):
                continue
            p = os.path.join(dp, f)
            s = open(p, encoding="utf-8").read()
            o = s
            for a, b in REPLACEMENTS:
                if a in s:
                    s = s.replace(a, b)
            for rx, b in REGEX_REPLACEMENTS:
                s = rx.sub(b, s)
            if s != o:
                open(p, "w", encoding="utf-8").write(s)
                changed[f] = True
    return sorted(changed)


def write_project(out, mc, api, loader, loom, mod_version):
    if os.path.exists(out):
        shutil.rmtree(out)
    os.makedirs(os.path.join(out, "src", "main"))
    major_minor = ".".join(mc.split(".")[:2])
    open(os.path.join(out, "settings.gradle"), "w").write(
        "pluginManagement {\n    repositories {\n        maven { name = 'Fabric'; url = 'https://maven.fabricmc.net/' }\n"
        "        mavenCentral()\n        gradlePluginPortal()\n    }\n}\nrootProject.name = 'PvPCalc-mc%s'\n" % mc)
    open(os.path.join(out, "gradle.properties"), "w").write(
        "org.gradle.jvmargs=-Xmx3G\norg.gradle.parallel=true\n"
        "minecraft_version=%s\nloader_version=%s\nloom_version=%s\nfabric_api_version=%s\nmod_version=%s+mc%s\n"
        "maven_group=com.pvpcalc\narchives_base_name=pvpcalc\n" % (mc, loader, loom, api, mod_version, mc))
    open(os.path.join(out, "build.gradle"), "w").write("""plugins {
    id 'net.fabricmc.fabric-loom' version "${loom_version}"
}

version = project.mod_version
group = project.maven_group

base {
    archivesName = project.archives_base_name
}

dependencies {
    minecraft "com.mojang:minecraft:${project.minecraft_version}"
    implementation "net.fabricmc:fabric-loader:${project.loader_version}"
    implementation "net.fabricmc.fabric-api:fabric-api:${project.fabric_api_version}"
}

processResources {
    inputs.property "version", project.version
    filesMatching("fabric.mod.json") {
        expand "version": inputs.properties.version
    }
}

tasks.withType(JavaCompile).configureEach {
    it.options.release = 25
    it.options.encoding = 'UTF-8'
}

java {
    sourceCompatibility = JavaVersion.VERSION_25
    targetCompatibility = JavaVersion.VERSION_25
}
""")
    # sources: the Mojang-named ones produced by migrateMappings
    mapped = os.path.join(ROOT, "remappedSrc")
    if not os.path.isdir(mapped):
        die("remappedSrc not found at %s - the migrateMappings step did not produce it" % mapped)
    shutil.copytree(mapped, os.path.join(out, "src", "main", "java"))
    # resources: unchanged, except the metadata
    shutil.copytree(os.path.join(ROOT, "src", "main", "resources"), os.path.join(out, "src", "main", "resources"))
    fmj = os.path.join(out, "src", "main", "resources", "fabric.mod.json")
    meta = json.load(open(fmj, encoding="utf-8"))
    meta["depends"]["minecraft"] = "~" + major_minor
    meta["depends"]["java"] = ">=25"
    meta["depends"]["fabricloader"] = ">=0.19.0"
    json.dump(meta, open(fmj, "w", encoding="utf-8"), indent=2)
    return major_minor


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mc", required=True)
    ap.add_argument("--out", default="_p26")
    ap.add_argument("--api"); ap.add_argument("--loader"); ap.add_argument("--loom"); ap.add_argument("--gradle")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    props = open(os.path.join(ROOT, "gradle.properties")).read()
    mod_version = re.search(r"^mod_version=(.+)$", props, re.M).group(1).strip()

    api = a.api or resolve_fabric_api(a.mc)
    loader = a.loader or resolve_loader()
    loom = a.loom or resolve_loom()
    print("Minecraft %s | Fabric API %s | Loader %s | Loom %s | mod %s" % (a.mc, api, loader, loom, mod_version), flush=True)

    out = os.path.abspath(a.out)
    write_project(out, a.mc, api, loader, loom, mod_version)
    changed = patch_sources(os.path.join(out, "src", "main", "java"))
    print("Patched %d source file(s) for the 26.x Fabric API: %s" % (len(changed), ", ".join(changed)), flush=True)
    if a.dry_run:
        print("dry run: project written to", out)
        return

    gradle = a.gradle or install_gradle(os.path.join(out, "_gradle"))
    cmd = [gradle, "build", "--console=plain", "--no-daemon"]
    print("Running:", " ".join(cmd), flush=True)
    sys.exit(subprocess.call(cmd, cwd=out))


if __name__ == "__main__":
    main()
